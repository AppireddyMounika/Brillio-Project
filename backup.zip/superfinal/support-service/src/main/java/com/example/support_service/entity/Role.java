package com.example.support_service.entity;

public enum Role {
    EMPLOYEE,
    USER,
    ADMIN
}
