package com.example.support_service.entity;

public enum TicketPriority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}