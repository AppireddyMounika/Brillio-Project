package com.example.authservice.model;

public enum UserRole {
    USER, EMPLOYEE, ADMIN
}