package com.example.planmanagementservice.exception;

public class PlanManagementException extends RuntimeException {
    public PlanManagementException(String message) {
        super(message);
    }
}